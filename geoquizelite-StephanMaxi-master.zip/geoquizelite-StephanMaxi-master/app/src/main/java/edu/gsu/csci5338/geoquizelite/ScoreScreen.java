package edu.gsu.csci5338.geoquizelite;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ScoreScreen extends AppCompatActivity {

    private int score;
    TextView mScore;
    Button Restart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_screen);
         mScore = (TextView) findViewById(R.id.score_text_view);

        SharedPreferences preferences = getSharedPreferences("PREFS",0);
        score = preferences.getInt("Score",0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("Score",score);
        editor.apply();
        mScore.setText("Score: " + score +"/7");
    }
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
        finish();

    }
}
