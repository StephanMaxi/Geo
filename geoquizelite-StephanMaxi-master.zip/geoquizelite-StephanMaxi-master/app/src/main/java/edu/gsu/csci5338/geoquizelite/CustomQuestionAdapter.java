package edu.gsu.csci5338.geoquizelite;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class CustomQuestionAdapter extends RecyclerView.Adapter<CustomQuestionAdapter.MyViewHolder> {
    private String[] mDataset;
    private Question[] questionList;
    private int questionCount;
    private int scoreCount;
    private boolean clicked;




    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case

        private TextView question;
        private TextView cheatTextView;
        private Button True;
        private Button False;
        private Button Cheat;
        private DBHelper mydb;




        public TextView getCheatTextView() {
            return cheatTextView;
        }

        public void setCheatTextView(TextView cheatTextView) {
            this.cheatTextView = cheatTextView;
        }

        public TextView getQuestion() {
            return question;
        }

        public void setQuestion(TextView question) {
            this.question = question;
        }

        public Button getTrue() {
            return True;
        }

        public void setTrue(Button aTrue) {
            True = aTrue;
        }

        public Button getFalse() {
            return False;
        }

        public void setFalse(Button aFalse) {
            False = aFalse;
        }

        public Button getCheat() {
            return Cheat;
        }

        public void setCheat(Button cheat) {
            Cheat = cheat;
        }




        public MyViewHolder(View v) {
            super(v);
            question = v.findViewById(R.id.question_text_view);
            True = v.findViewById(R.id.true_button);
            False = v.findViewById(R.id.false_button);
            Cheat = v.findViewById(R.id.cheat_button);
            cheatTextView = v.findViewById(R.id.cheat_text_view);
            mydb = new DBHelper(this);



            True.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    True.setEnabled(false);
                    False.setEnabled(false);
                    Cheat.setEnabled(false);
                }
            });

            False.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    True.setEnabled(false);
                    False.setEnabled(false);
                    Cheat.setEnabled(false);
                }
            });

            Cheat.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Cheat.setEnabled(false);
                }
            });


        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public CustomQuestionAdapter(Question[] questions){
        this.questionList = questions;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public CustomQuestionAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;

        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.question_list_layout, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return (MyViewHolder)vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        showQuestion(holder, position);

    }

    private void showQuestion(final MyViewHolder vh1 , final int pos){
        switch (pos){
            case 0:
                vh1.getQuestion().setText(R.string.question_1);
                break;
            case 1:
                vh1.getQuestion().setText(R.string.question_2);
                break;
            case 2:
                vh1.getQuestion().setText(R.string.question_3);
                break;
            case 3:
                vh1.getQuestion().setText(R.string.question_4);
                break;
            case 4:
                vh1.getQuestion().setText(R.string.question_5);
                break;
            case 5:
                vh1.getQuestion().setText(R.string.question_6);
                break;
            case 6:
                vh1.getQuestion().setText(R.string.question_7);
                break;
            case 7:
                vh1.getQuestion().setText(R.string.question_8);
                break;
            case 8:
                vh1.getQuestion().setText(R.string.question_9);
                break;
            case 9:
                vh1.getQuestion().setText(R.string.question_10);
                break;
                default:
                    vh1.getQuestion().setText(R.string.question_1);
                    break;
        }
      //  vh1.getQuestion().setText(R.string.question_1);
        vh1.getTrue().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(questionList[pos].isAnswerTrue()){
                    vh1.getTrue().setBackgroundColor(Color.GREEN);
                    vh1.getFalse().setBackgroundColor(Color.GREEN);
                    vh1.getQuestion().setBackgroundColor(Color.GREEN);
                    scoreCount++;

                }else{
                    vh1.getTrue().setBackgroundColor(Color.RED);
                    vh1.getFalse().setBackgroundColor(Color.RED);
                    vh1.getQuestion().setBackgroundColor(Color.RED);
                }
                questionCount++;

                if(questionCount == 7){
                    SharedPreferences preferences = v.getContext().getSharedPreferences("PREFS",0);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putInt("Score",scoreCount);
                    editor.apply();
                    v.getContext().startActivity(new Intent(v.getContext(),ScoreScreen.class));
                }
                vh1.getTrue().setEnabled(false);
                vh1.getFalse().setEnabled(false);
                vh1.getCheat().setEnabled(false);
                clicked = true;

            }
        });

        vh1.getFalse().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(questionList[pos].isAnswerTrue()){
                    vh1.getTrue().setBackgroundColor(Color.RED);
                    vh1.getFalse().setBackgroundColor(Color.RED);
                    vh1.getQuestion().setBackgroundColor(Color.RED);
                }else{
                    vh1.getTrue().setBackgroundColor(Color.GREEN);
                    vh1.getFalse().setBackgroundColor(Color.GREEN);
                    vh1.getQuestion().setBackgroundColor(Color.GREEN);
                    scoreCount++;
                }
                questionCount++;
                if(questionCount == 7) {
                    SharedPreferences preferences = v.getContext().getSharedPreferences("PREFS",0);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putInt("Score",scoreCount);
                    editor.apply();
                    v.getContext().startActivity(new Intent(v.getContext(),ScoreScreen.class));
                }
                vh1.getTrue().setEnabled(false);
                vh1.getFalse().setEnabled(false);
                vh1.getCheat().setEnabled(false);
                clicked = true;
            }
        });

        vh1.getCheat().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(questionList[pos].isAnswerTrue()) {
                    vh1.getCheatTextView().setText("True");
                }else{
                    vh1.getCheatTextView().setText("False");
                }
                vh1.getCheat().setEnabled(false);
            }
        });

    }
    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return questionList.length;
    }
}
